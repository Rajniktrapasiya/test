function adminButton() {
    document.getElementById("adminButton").type = "hidden";
    location.replace("Regitstration.html")
}
var admin;
var adminData = function (name, Email, Password, city, state) {
    this.Name = name;
    this.Email = Email;
    this.City = city;
    this.Password = Password;
    this.State = state;
}
function loginPage()
{
    if(sessionStorage.admin == undefined)
    {
        sessionStorage.admin = 0;
    }
    if(sessionStorage.admin == 0)
    {
    var data = `<div id="logindiv">
                    <h1>Login</h1>
                    <div id="subDiv" >
                    <input type="text" name="email" placeholder="Email" id="email"><br><br>
                    <input type="password" placeholder="Password" id="password"><br><br>
                    <input type="button" onclick="userlogin()" value="Login">
                    <br>OR<br>
                    <input type="button" onclick="adminButton()" value="REGISTER NOW " id="adminButton">
                    </div>
                    </div>`
    }else{
        var data = `<div id="logindiv">
        <h1>Login</h1>
        <div id="subDiv" >
        <input type="text" name="email" placeholder="Email" id="email"><br><br>
        <input type="password" placeholder="Password" id="password"><br><br>
        <input type="button" onclick="userlogin()" value="Login">
        </div>
        </div>`
    }
    document.getElementById("index").innerHTML = data;

}
function adminRegistration() {

    var name = document.getElementById('name').value;
    var email = document.getElementById('email').value;
    var password = document.getElementById('password').value;
    var confirmPassword = document.getElementById('confirmPassword').value;
    var city = document.getElementById('city').value;
    var state = document.getElementById('state').value;
    var agree = document.getElementById('agree');
    var bol = false;
    if (name == "") {
        alert("Please Enter Valid name");
        return false;
    }
    if (email == "") {
        alert("Please Enter Email");
        return false;
    }
    if (password == "") {
        alert("Password is not empty");
        return false;
    }
    if (confirmPassword == "") {
        alert("confirmPassword is not empty");
        return false;
    }
    if (city == "") {
        alert("city is not Empty");
        return false;
    }
    if (state == "") {
        alert("state is not Empty");
        return false;
    }
    if (password != confirmPassword) {
        alert("Enter valid Confirm password");
    }
    if(agree.checked == true){
         bol = true;
     }
     else{
         alert("Please select term and condition");
     }

    if (validName(name) == true && validEmail(email) == true && ValidPass(password) == true && validCity(city) == true && validState(state) == true && bol == true) {
        admin = new adminData(name, email, password, city, state);
        localStorage.setItem("admin", JSON.stringify(admin));
        console.log("calls");
        console.log(admin);
        console.log(admin.Name);
        sessionStorage.admin = 1;
        alert("Data Update SuccessFul");
        location.replace("Dashboard.html")

    }


    function validName(name) {
        if (/^[a-z,A-Z]{3,20}$/.test(name)) {
            return true;
        }
        else {
            alert("Enter Valid Name");
            return false;
        }
    }
    function validCity(name) {
        if (/^[a-z,A-Z]{3,20}$/.test(name)) {
            return true;
        }
        else {
            alert("Enter valid City");
            return false;
        }
    }
    function validState(name) {
        if (/^[a-z,A-Z]{3,20}$/.test(name)) {
            return true;
        }
        else {
            alert("Enter valid State");
            return false;
        }
    }
    function validEmail(email) {
        if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email)) {
            return true;
        }
        else {
            alert("Enter Vadil Email");
            return false;
        }
    }
    function ValidPass(pass) {
        if (/^(?=.*\d)(?=.*[A-Z])(?=.*[a-z]).{7,15}$/.test(pass)) {
            return true;
        }
        else {
            alert("Enter Strong Password: It should be contain One Upper-Lower-Digit-specialCharacter and 7 to 8 digit.");
            return false;
        }
    }
}

function adminNavigationDiv()
{
    var admin = JSON.parse(localStorage.getItem('admin'));
    var nav = '<h1>Hello ' + admin.Name + '</h1><br><br><br><br><a href="Dashboard.html">Dashboad</a><br><br><a href="User.html">Users</a><br><br><a href="UserSession.html">Login Session</a><br><br><a href="webApp.html">LogOut</a>'
    document.getElementById("nav").innerHTML = nav;
}

function displayDashbord() {
    adminNavigationDiv();
    var userDataList = JSON.parse(localStorage.getItem('userDataList'));
    var less18 = 0, bet18_50 = 0, gat50 = 0;
    for (var i = 0; i < userDataList.length; i++) {
        if (userDataList[i].Age < 18) {
            less18++;
        }
        if (userDataList[i].Age > 18 && userDataList[i].Age < 50) {
            bet18_50++;
        }
        if (userDataList[i].Age > 50) {
            gat50++;
        }
    }
    var deshbord = '<div class="useranalysis" ><div class="subuser" align="center"><p>User< 18Years</p><br><br><br><p>User' + less18 + '</p></div><div class="subuser" align="center"><p> 18 -50 Years Users</p><br><br><br><p>User' + bet18_50 + '</p></div><div class="subuser" align="center"><p>User>50 Years</p><br><br><br><p>User' + gat50 + '</p></div></div>'
    document.getElementById("deshbord").innerHTML = deshbord;
}


var userData = function (name, email, password, birthdate) {
    this.Name = name;
    this.Email = email;
    this.Password = password;
    this.Birthdate = birthdate;
    console.log(this.Birthdate);
    this.Age = 2020 - Number(this.Birthdate.slice(0, 4));
}
var userDataList = [];


function addUser() {
    var name = document.getElementById('userName').value;
    var email = document.getElementById('userEmail').value;
    var password = document.getElementById('userPassword').value;
    var birthdate = document.getElementById('userBirthDate').value;
    if (name == "") {
        alert("Please Enter Valid name");
        return false;
    }
    if (email == "") {
        alert("Please Enter Email");
        return false;
    }
    if (password == "") {
        alert("Password is not empty");
        return false;
    }
    if (birthdate == "") {
        alert("birthdate is not empty");
        return false;
    }

    var userDataList = JSON.parse(localStorage.getItem('userDataList'));
    var tempdata = new userData(name, email, password, birthdate);
    userDataList.push(tempdata);
    localStorage.setItem("userDataList", JSON.stringify(userDataList));
    resetUserInputField()
    displayUser();
}
function displayUser() {
    adminNavigationDiv();
    var data = "<tr><th>Name</th><th>Email</th><th>Password</th><th>BirthDate</th><th>Age</th><th>Action</th></tr>";
    var userDataList = JSON.parse(localStorage.getItem('userDataList'));
    for (var i = 0; i < userDataList.length; i++) {
        data += '<tr><td>' + userDataList[i].Name + '</td><td>' + userDataList[i].Email + '</td><td>' + userDataList[i].Password + '</td><td>' + userDataList[i].Birthdate + '</td><td>' + userDataList[i].Age + '</td><td><a href="javascript:userEdit(' + i + ')">Edit  </a><a href="javascript:userDelete(' + i + ')">Delete</a></td></tr>'
    }
    document.getElementById("table").innerHTML = data;

}
function userDelete(i) {
    var userDataList = JSON.parse(localStorage.getItem('userDataList'));
    userDataList.splice(i, 1);
    localStorage.setItem("userDataList", JSON.stringify(userDataList));
    console.log("delete  " + i);
    displayUser();
}
function userEdit(i) {
    var userDataList = JSON.parse(localStorage.getItem('userDataList'));
    document.getElementById("userName").value = userDataList[i].Name;
    document.getElementById("userEmail").value = userDataList[i].Email;
    document.getElementById("userPassword").value = userDataList[i].Password;
    document.getElementById("userBirthDate").value = userDataList[i].Birthdate;
    document.getElementById("btn").value = "Update User";
    document.getElementById("btn").setAttribute("onClick", "updateRecord(" + i + ")");
    console.log("calling" + i);


}
function updateRecord(i) {
    var name = document.getElementById('userName').value;
    var email = document.getElementById('userEmail').value;
    var password = document.getElementById('userPassword').value;
    var birthdate = document.getElementById('userBirthDate').value;
    var userDataList = JSON.parse(localStorage.getItem('userDataList'));
    var tempdata = new userData(name, email, password, birthdate);
    userDataList.splice(i, 1, tempdata);
    localStorage.setItem("userDataList", JSON.stringify(userDataList));
    console.log(userDataList);
    resetUserInputField();
    displayUser();
}

function resetUserInputField()
{
    document.getElementById("userName").value = "";
    document.getElementById("userEmail").value ="";
    document.getElementById("userPassword").value = "";
    document.getElementById("userBirthDate").value = "";
    document.getElementById("btn").value = "add User";
    document.getElementById("btn").setAttribute("onClick", "addUser()");
}

var userSessionData = function (name, logintime,logout) {
    this.Name = name;
    this.LoginDate = logintime;
    this.LogOut = logout;
}
 var logoutArr = [];
 localStorage.setItem("logoutArr", JSON.stringify(logoutArr));
var userSessionDataList = [];
function userlogin() {
    var userDataList = JSON.parse(localStorage.getItem('userDataList'));
    var userName = document.getElementById("email").value;
    var Password = document.getElementById("password").value;
    var bol = false;
    var d = new Date();
    for (var i = 0; i < userDataList.length; i++) {
        if (userName == userDataList[i].Email && Password == userDataList[i].Password) {
            var userSession = new userSessionData(userDataList[i].Name, d ,0);
            console.log(userSession);
            userSessionDataList.push(userSession);
            localStorage.setItem("userSessionDataList", JSON.stringify(userSessionDataList));
            currentUserIndex = i;
            if(sessionStorage.user == 'undifined')
            {
                sessionStorage.user =0;
            }
            else{
                sessionStorage.user = i;
            }
            location.replace("Sub-user.html");
            bol = true;
        }
    }
    if (bol == false) {
        alert("Enter Valid Password");
    }
}

function userSession() {
    adminNavigationDiv();
    var userSessionDataList = JSON.parse(localStorage.getItem('userSessionDataList'));
    var data = "<tr><th>Name</th><th>Login Date Time</th><th>LOGOUT Date Time</th></tr>";
    for (var i = 0; i < userSessionDataList.length; i++) {
        data += "<tr><th>" + userSessionDataList[i].Name + "</th><th>" + userSessionDataList[i].LoginDate + "</th><th>" + logoutArr[i] + "</th></tr>";
    }
    console.log(userSessionDataList);
    document.getElementById("table2").innerHTML = data;

}
function subUser() {
    var userDataList = JSON.parse(localStorage.getItem('userDataList'));
    var nav = '<h1>Hello ' + userDataList[Number(sessionStorage.user)].Name + '</h1><br><br><br><br><a href="#">Dashboad</a><br><br><a href="javascript:userLogout()">Logout</a><br><br>'
    document.getElementById("nav").innerHTML = nav;
}
function userLogout()
{
    console.log("logout");
    var d = Date();
    console.log(d);
    logoutArr.push(d);
    localStorage.setItem("logoutArr", JSON.stringify(logoutArr));
    console.log(logoutArr);
    //location.replace("webApp.html");
}